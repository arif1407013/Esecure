import { AuthGuard } from './../auth.guard';
import { UserService } from './../services/user.service';
import { IUserModel } from './../models/iuser-model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  public user: IUserModel = {Username:"",Password:"",Email:""};
  public listUser: IUserModel[] = [];
  //private btnDis: boolean = true;

  constructor(private route: Router, private userList: UserService, private guard: AuthGuard) {
    this.userList.checkData().subscribe(i=>{this.listUser = i;});
    this.guard.guardKey = false;
  }

  /**
   * submitter
   */
  public submitter() {
    //console.log(this.user);
    let truth: boolean = false;
    for(let i=0;i<this.listUser.length;i++){
      if(this.listUser[i].Username == this.user.Username || this.listUser[i].Email == this.user.Email){
        truth = false;
        break;
      }
      else{
        truth = true;
      }
    }
    if(truth){
      this.userList.addData(this.user);
      this.guard.guardKey = true;
      sessionStorage.setItem("UserName", this.user.Username);
    }
    this.user.Username = "";
    this.user.Password = "";
    this.user.Email = "";
    this.route.navigate(['/chat']);
  }

  /**
   * btnDis
   */
  public tryDis(): boolean {
    //console.log(this.btnDis);
    if(this.user.Username == "" || this.user.Password == "" || this.user.Email == "")
    {
      //this.btnDis = true;
      return true;
    }
    else{
      //this.btnDis = false;
      return false;
    }
    //return this.btnDis;
  }

  ngOnInit(): void {
  }

}
