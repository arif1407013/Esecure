export interface IUserModel {
    Username: string;
    Password: string;
    Email: string;
    Key?: string;
}
