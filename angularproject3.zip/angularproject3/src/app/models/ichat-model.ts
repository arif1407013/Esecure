export interface IChatModel {
    Message: string;
    Owner: string;
    Time: Date;
}
