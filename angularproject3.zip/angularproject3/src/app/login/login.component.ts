import { AuthGuard } from './../auth.guard';
import { IUserModel } from './../models/iuser-model';
import { UserService } from './../services/user.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public listUser: IUserModel[] = [];

  public loginForm = this.formBuild.group({
    Name: ['', Validators.required],
    Password: ['', Validators.required],
  });

  constructor(private formBuild: FormBuilder, 
              private userList: UserService, 
              private guard: AuthGuard, 
              private router: Router) {
    this.guard.guardKey = false;
    this.userList.showData().subscribe(i=>{
      console.log(i);
      i.forEach(x=>{
        let tempUser: IUserModel = {Username: "", Password: "", Email: "", Key: ""};
        tempUser.Key = x.key;
        tempUser.Password = x.payload.node_.children_.root_.value.value_;
        tempUser.Email = x.payload.node_.children_.root_.left.value.value_;
        tempUser.Username = x.payload.node_.children_.root_.right.value.value_;
        //console.log(x);
        //console.log(tempUser);
        this.listUser.push(tempUser);
        this.listUser.sort((i,j)=>i.Username.charCodeAt(0)-j.Username.charCodeAt(0));
      });
    });
  }

  /**
   * submitter
   */
  public submitter() {
    //console.log(this.loginForm.value);
    //console.log(this.listUser);
    for(let i=0;i<this.listUser.length;i++){
      if(this.listUser[i].Username == this.loginForm.value.Name && this.listUser[i].Password == this.loginForm.value.Password){
        this.guard.guardKey = true;
        break;
      }
      else{
        this.guard.guardKey = false;
      }
    }
    sessionStorage.setItem("UserName", this.loginForm.value.Name);
    this.router.navigate(['/chat']);
    this.loginForm.reset();
  }

  ngOnInit(): void {
  }

}
